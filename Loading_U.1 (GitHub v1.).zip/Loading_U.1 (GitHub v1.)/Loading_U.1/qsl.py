import sqlite3 as sql
import time

"r" == True
while True:
    
    print("\n Please Login.... \n")
    print("----------------->")

    username = input("Username: ")
    password = input("Password: ")

    print("----------------->")

    con = sql.connect("landp.db") #Name of the .sql file
    cur = con.cursor()

    statement = f"SELECT username from Login WHERE username='{username}' AND Password = '{password}';"
    cur.execute(statement)

    if not cur.fetchone(): #Fetches login details and decides if it matches up
        
        print()
        print("Login failed")
        print("Please try again")
        time.sleep(3)
    
    else:
        
        print()
        print("Welcome",username,"!")

   
    break

Yes = input("\nPress T and then ENTER to continue.... ")
if Yes == "T" or Yes == "t":
    
    print()
    print("  LOADING [█▒▒▒▒▒▒▒▒]")
    time.sleep(2)
    print("  LOADING [██▒▒▒▒▒▒▒]")
    time.sleep(3)
    print("  LOADING [███▒▒▒▒▒▒]")
    time.sleep(1)
    print("  LOADING [████▒▒▒▒▒]")
    time.sleep(0.5)
    print("  LOADING [██████▒▒▒]")
    time.sleep(1.7)
    print("  LOADING [████████▒]")
    time.sleep(5)
    print("  LOADING [█████████]")
    print()
    print("  [FINISHING LOADING.....]")
    time.sleep(3)
    print("  [LOADING COMPLETE]")
    time.sleep(10)
    
else:
    print("Please press T ")


