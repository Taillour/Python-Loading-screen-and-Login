import sqlite3 as sql
import time

"r" == True
while True:
    
    print("\n Please Login.... \n")
    print("----------------->")

    username = input("Username: ")
    password = input("Password: ")

    print("----------------->")

    con = sql.connect("landp.db") #Name of the .sql file
    cur = con.cursor()

    statement = f"SELECT username from Login WHERE username='{username}' AND Password = '{password}';"
    cur.execute(statement)

    if not cur.fetchone(): #Fetches login details and decides if it matches up
        
        print()
        print("Login failed")
        print("Please try again")
        time.sleep(3)
    
    else:
        
        print()
        print("Welcome",username,"!")

   
    break
